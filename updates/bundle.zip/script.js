(function () {
  // ---- Difficulty presets -------------------------------------------------
  // COLS/ROWS/MAX_VALUE are now mutable and set by applyDifficulty() at game
  // start based on the menu selection, instead of being fixed module consts.
  const DIFFICULTIES = {
    easy:   { cols: 6,  rows: 4, maxValue: 5, label: 'Easy' },
    normal: { cols: 8,  rows: 5, maxValue: 9, label: 'Normal' },
    hard:   { cols: 10, rows: 7, maxValue: 9, label: 'Hard' },
  };
  const TIME_OPTIONS = [30, 60, 120, 180]; // seconds; 'zen' handled separately
  const DEFAULT_DIFFICULTY = 'normal';
  const DEFAULT_SECONDS = 60;
  const LEVEL_TARGET_SUM = 10; // fixed rectangle sum used by every Level (only Classic's is configurable)
  const TARGET_GOAL_MIN = 10;
  const TARGET_GOAL_MAX = 50;
  const TARGET_GOAL_STEP = 1;

  // Fruit kinds available to Levels mode. A level's `fruits` count (see LEVELS
  // below) picks the first N of these; levels that omit `fruits` default to 1
  // (apple-only, same as before this feature existed). When more than one
  // fruit kind is active, a valid selection must be all the same kind — see
  // isMultiFruit() and its call sites.
  const FRUIT_KINDS = ['apple', 'orange'];

  const LEVELS = [
    { cols: 6,  rows: 4, maxValue: 3, seconds: 120, target: 10 },
    { cols: 6,  rows: 5, maxValue: 3, seconds: 120, target: 14 },
    { cols: 7,  rows: 5, maxValue: 4, seconds: 120, target: 20 },
    { cols: 8,  rows: 5, maxValue: 4, seconds: 120, target: 26 },
    { cols: 8,  rows: 6, maxValue: 5, seconds: 120, target: 32 },
    { cols: 9,  rows: 6, maxValue: 5, seconds: 120, target: 38 },
    { cols: 10, rows: 7, maxValue: 6, seconds: 120, target: 46 },
    { cols: 11, rows: 7, maxValue: 7, seconds: 120, target: 54 },
    { cols: 12, rows: 8, maxValue: 8, seconds: 120, target: 64 },
    { cols: 14, rows: 9, maxValue: 9, seconds: 120, target: 75 },
    { cols: 14, rows: 9, maxValue: 9, seconds: 120, target: 80, fruits: 2 },
  ];

  const LS_SETTINGS_KEY = 'appleGame.settings';
  const LS_BEST_KEY = 'appleGame.bestScores';
  const LS_TUTORIAL_KEY = 'appleGame.tutorialSeen';
  const LS_LEVEL_PROGRESS_KEY = 'appleGame.levelProgress';
  const LS_CURRENCY_KEY = 'appleGame.currency';
  const CONTINUE_BASE_COST = 100; // currency price for the first continue purchase in a level attempt
  const CONTINUE_COST_STEP = 50; // each additional continue within the same attempt costs this much more
  const CONTINUE_SECONDS = 10;
  const HINT_COST = 100;

  let COLS = DIFFICULTIES[DEFAULT_DIFFICULTY].cols;
  let ROWS = DIFFICULTIES[DEFAULT_DIFFICULTY].rows;
  let MAX_VALUE = DIFFICULTIES[DEFAULT_DIFFICULTY].maxValue;
  let GAME_SECONDS = DEFAULT_SECONDS;

  let selectedDifficulty = DEFAULT_DIFFICULTY;
  let selectedTime = DEFAULT_SECONDS; // number of seconds, or 'zen'
  let zenMode = false;
  let selectedTargetGoal = TARGET_GOAL_MIN; // Classic mode's required rectangle sum, set via the stepper

  let gameMode = 'classic'; // 'classic' | 'levels'
  let activeFruitKinds = ['apple']; // fruit kinds live on the current board; see FRUIT_KINDS
  let currentLevel = 0; // 1-based index into LEVELS when gameMode === 'levels'
  let levelTarget = 0;
  let targetSum = TARGET_GOAL_MIN; // sum a selected rectangle must hit to clear; 10 for levels, stepper-controlled for classic

  const hudEl = document.getElementById('hud');
  const board = document.getElementById('board');
  const boardWrap = document.getElementById('board-wrap');
  const selectionBox = document.getElementById('selection-box');
  const reshuffleBanner = document.getElementById('reshuffle-banner');
  const scoreEl = document.getElementById('score');
  const scoreLabelEl = document.getElementById('score-label');
  const timeEl = document.getElementById('time');
  const sumEl = document.getElementById('selected-sum');
  const startOverlay = document.getElementById('start-overlay');
  const gameoverOverlay = document.getElementById('gameover-overlay');
  const gameoverTitleEl = document.getElementById('gameover-title');
  const finalScoreEl = document.getElementById('final-score');
  const startBtn = document.getElementById('start-btn');
  const restartBtn = document.getElementById('restart-btn');
  const classicBackBtn = document.getElementById('classic-back-btn');
  const pauseOverlay = document.getElementById('pause-overlay');
  const pauseContinueBtn = document.getElementById('pause-continue-btn');
  const pauseRetryBtn = document.getElementById('pause-retry-btn');
  const pauseQuitBtn = document.getElementById('pause-quit-btn');
  const pauseSettingsBtn = document.getElementById('pause-settings-btn');

  const lobbyOverlay = document.getElementById('lobby-overlay');
  const lobbyLevelsBtn = document.getElementById('lobby-levels-btn');
  const lobbyClassicBtn = document.getElementById('lobby-classic-btn');

  const levelSelectOverlay = document.getElementById('level-select-overlay');
  const levelGridEl = document.getElementById('level-grid');
  const levelSelectBackBtn = document.getElementById('level-select-back-btn');

  const levelResultOverlay = document.getElementById('level-result-overlay');
  const levelResultTitleEl = document.getElementById('level-result-title');
  const levelResultScoreEl = document.getElementById('level-result-score');
  const levelNextBtn = document.getElementById('level-next-btn');
  const levelRetryBtn = document.getElementById('level-retry-btn');
  const levelBackBtn = document.getElementById('level-back-btn');
  const levelContinueBtn = document.getElementById('level-continue-btn');
  const levelIntroOverlay = document.getElementById('level-intro-overlay');
  const levelIntroTargetEl = document.getElementById('level-intro-target');
  const levelIntroCountdownEl = document.getElementById('level-intro-countdown');
  let levelIntroTimerId = null;
  const currencyDisplayEl = document.getElementById('currency-display');
  const currencyHudItemEl = document.getElementById('currency-hud-item');
  const levelSelectCurrencyDisplayEl = document.getElementById('level-select-currency-display');

  const difficultyOptionsEl = document.getElementById('difficulty-options');
  const timerOptionsEl = document.getElementById('timer-options');
  const targetMinusBtn = document.getElementById('target-minus-btn');
  const targetPlusBtn = document.getElementById('target-plus-btn');
  const targetGoalValueEl = document.getElementById('target-goal-value');
  const targetSumHintEl = document.getElementById('target-sum-hint');
  const bestScoreDisplayEl = document.getElementById('best-score-display');
  const gameoverBestEl = document.getElementById('gameover-best');
  const newBestCalloutEl = document.getElementById('new-best-callout');

  const helpBtnMenu = document.getElementById('help-btn-menu');
  const helpBtnHud = document.getElementById('help-btn-hud');
  const pauseBtnHud = document.getElementById('pause-btn-hud');
  const hintBtnHud = document.getElementById('hint-btn-hud');
  const hintConfirmPopover = document.getElementById('hint-confirm-popover');
  const hintConfirmText = document.getElementById('hint-confirm-text');
  const hintConfirmBtn = document.getElementById('hint-confirm-btn');
  const settingsBtn = document.getElementById('settings-btn');
  const settingsOverlay = document.getElementById('settings-overlay');
  const settingsCloseBtn = document.getElementById('settings-close-btn');
  const tutorialOverlay = document.getElementById('tutorial-overlay');
  const tutorialCloseBtn = document.getElementById('tutorial-close-btn');
  const soundToggle = document.getElementById('sound-toggle');
  const bigToggle = document.getElementById('big-toggle');
  const themeToggle = document.getElementById('theme-toggle');
  const beginnerToggle = document.getElementById('beginner-toggle');
  const selectionStyleOptionsEl = document.getElementById('selection-style-options');

  let cells = []; // {row, col, value, removed, el}
  let cellSize = 0;
  let boardRect = { left: 0, top: 0 };
  let score = 0;
  let timeLeft = GAME_SECONDS;
  let elapsed = 0;
  let timerId = null;
  let running = false;
  let paused = false;
  let reshuffling = false;
  let tutorialPausedGame = false;

  let dragging = false;
  let startRow = 0, startCol = 0, curRow = 0, curCol = 0;
  // Last rectangle actually rendered to the DOM (for diff-based updates), or
  // null when nothing is currently marked selected.
  let renderedRect = null;
  // rAF-coalescing state for pointermove: we only want to do the (still cheap,
  // but non-zero) selection recompute + DOM write once per animation frame,
  // even if the browser delivers many pointermove events per frame during a
  // fast touch drag.
  let pendingClientX = 0, pendingClientY = 0;
  let moveRafScheduled = false;

  // Trace selection mode: an ordered path of cells the player has traced with
  // their finger (as opposed to Box mode's two-corner rectangle). There is no
  // backtracking — once a cell is traced it stays selected for the rest of
  // the drag. traceCurrentCell is the cell the finger is presently over
  // (which may be an earlier cell in the path, revisited to resume tracing
  // from there toward new cells beyond it). tracePrevCells is the
  // previously-rendered path, kept around so updateTraceVisual can diff
  // highlight state instead of touching every cell.
  let tracePath = [];
  let tracePrevCells = [];
  let traceCurrentCell = null;

  // ---- Settings / persistence ---------------------------------------------
  const settings = loadSettings();
  applySettingsToUI();
  applySettingsToDom();

  const bestScores = loadBestScores();
  const levelProgress = loadLevelProgress();
  let currency = loadCurrency();
  let continueCount = 0; // how many times the current level attempt has paid for extra time
  updateCurrencyDisplay();

  // ---- Sound ----------------------------------------------------------------
  let audioCtx = null;
  // Exposed purely so automated tests can confirm the sound code path is
  // (or isn't) invoked without needing actual audio playback.
  window.__appleGameTestHooks = {
    soundPlayCount: 0,
    getSettings: () => ({ ...settings }),
    getBestScores: () => ({ ...bestScores }),
    getState: () => ({
      cols: COLS, rows: ROWS, maxValue: MAX_VALUE,
      running, zenMode, timeLeft, score,
      selectedDifficulty, selectedTime,
      gameMode, currentLevel, levelTarget, targetSum,
    }),
  };

  function playPopSound() {
    window.__appleGameTestHooks.soundPlayCount++;
    if (!settings.sound) return;
    try {
      if (!audioCtx) {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        audioCtx = new Ctx();
      }
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.16);
    } catch (err) {
      // WebAudio unavailable; silently ignore.
    }
  }

  function loadSettings() {
    let parsed = null;
    try { parsed = JSON.parse(localStorage.getItem(LS_SETTINGS_KEY)); } catch (e) {}
    return Object.assign({ sound: true, big: false, theme: 'dark', beginner: true, selectionMode: 'box' }, parsed || {});
  }

  function saveSettings() {
    try { localStorage.setItem(LS_SETTINGS_KEY, JSON.stringify(settings)); } catch (e) {}
  }

  function applySettingsToUI() {
    setToggleBtn(soundToggle, settings.sound, 'On', 'Off');
    setToggleBtn(bigToggle, settings.big, 'On', 'Off');
    setToggleBtn(themeToggle, settings.theme === 'light', 'Light', 'Dark');
    setToggleBtn(beginnerToggle, settings.beginner, 'On', 'Off');
  }

  function setToggleBtn(btn, on, onLabel, offLabel) {
    btn.dataset.on = String(on);
    btn.textContent = on ? onLabel : offLabel;
  }

  function applySettingsToDom() {
    document.body.classList.toggle('big-mode', !!settings.big);
    document.body.classList.toggle('theme-light', settings.theme === 'light');
  }

  function loadCurrency() {
    const parsed = parseInt(localStorage.getItem(LS_CURRENCY_KEY), 10);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function saveCurrency() {
    try { localStorage.setItem(LS_CURRENCY_KEY, String(currency)); } catch (e) {}
  }

  function updateCurrencyDisplay() {
    currencyDisplayEl.textContent = String(currency);
    levelSelectCurrencyDisplayEl.textContent = `🍎 ${currency}`;
  }

  function currentContinueCost() {
    return CONTINUE_BASE_COST + continueCount * CONTINUE_COST_STEP;
  }

  function loadBestScores() {
    let parsed = null;
    try { parsed = JSON.parse(localStorage.getItem(LS_BEST_KEY)); } catch (e) {}
    return Object.assign({}, parsed || {});
  }

  function saveBestScores() {
    try { localStorage.setItem(LS_BEST_KEY, JSON.stringify(bestScores)); } catch (e) {}
  }

  function bestScoreKey() {
    return `${selectedDifficulty}_${selectedTime}`;
  }

  function loadLevelProgress() {
    let parsed = null;
    try { parsed = JSON.parse(localStorage.getItem(LS_LEVEL_PROGRESS_KEY)); } catch (e) {}
    return Object.assign({ unlocked: 1, completed: [] }, parsed || {});
  }

  function saveLevelProgress() {
    try { localStorage.setItem(LS_LEVEL_PROGRESS_KEY, JSON.stringify(levelProgress)); } catch (e) {}
  }

  function refreshBestScoreDisplay() {
    bestScoreDisplayEl.textContent = `Best: ${bestScores[bestScoreKey()] || 0}`;
  }

  // ---- Menu option selection -----------------------------------------------
  function setupOptionGroup(container, onSelect, initialValue) {
    const buttons = Array.from(container.querySelectorAll('.option-btn'));
    buttons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.value === String(initialValue));
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        onSelect(btn.dataset.value);
      });
    });
  }

  setupOptionGroup(difficultyOptionsEl, (value) => {
    selectedDifficulty = value;
    refreshBestScoreDisplay();
  }, selectedDifficulty);

  setupOptionGroup(timerOptionsEl, (value) => {
    selectedTime = value === 'zen' ? 'zen' : parseInt(value, 10);
    refreshBestScoreDisplay();
  }, selectedTime);

  setupOptionGroup(selectionStyleOptionsEl, (value) => {
    settings.selectionMode = value;
    saveSettings();
  }, settings.selectionMode);

  // ---- Target goal stepper --------------------------------------------------
  function updateTargetGoalDisplay() {
    targetGoalValueEl.textContent = String(selectedTargetGoal);
    targetSumHintEl.textContent = String(selectedTargetGoal);
    targetMinusBtn.disabled = selectedTargetGoal <= TARGET_GOAL_MIN;
    targetPlusBtn.disabled = selectedTargetGoal >= TARGET_GOAL_MAX;
  }

  targetMinusBtn.addEventListener('click', () => {
    selectedTargetGoal = Math.max(TARGET_GOAL_MIN, selectedTargetGoal - TARGET_GOAL_STEP);
    updateTargetGoalDisplay();
  });
  targetPlusBtn.addEventListener('click', () => {
    selectedTargetGoal = Math.min(TARGET_GOAL_MAX, selectedTargetGoal + TARGET_GOAL_STEP);
    updateTargetGoalDisplay();
  });
  updateTargetGoalDisplay();

  refreshBestScoreDisplay();

  // ---- Grid building / layout ----------------------------------------------
  function applyDifficulty(diffKey) {
    const cfg = DIFFICULTIES[diffKey] || DIFFICULTIES[DEFAULT_DIFFICULTY];
    COLS = cfg.cols;
    ROWS = cfg.rows;
    MAX_VALUE = cfg.maxValue;
  }

  function computeEffectiveSeconds(diffKey, baseSeconds) {
    if (diffKey === 'hard') {
      return Math.max(15, Math.round(baseSeconds * 0.8));
    }
    return baseSeconds;
  }

  function buildGrid() {
    board.innerHTML = '';
    cells = [];
    renderedRect = null;
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const value = 1 + Math.floor(Math.random() * MAX_VALUE);
        const fruit = activeFruitKinds[Math.floor(Math.random() * activeFruitKinds.length)];
        const el = document.createElement('div');
        el.className = 'apple';
        if (fruit !== 'apple') el.classList.add(`fruit-${fruit}`);
        const num = document.createElement('span');
        num.className = 'num';
        num.textContent = value;
        el.appendChild(num);
        board.appendChild(el);
        cells.push({ row: r, col: c, value, fruit, removed: false, el });
      }
    }
    layout();
  }

  function layout() {
    const wrapRect = boardWrap.getBoundingClientRect();
    const availW = wrapRect.width * 0.92;
    const availH = wrapRect.height * 0.92;
    cellSize = Math.floor(Math.min(availW / COLS, availH / ROWS));
    board.style.gridTemplateColumns = `repeat(${COLS}, ${cellSize}px)`;
    board.style.gridTemplateRows = `repeat(${ROWS}, ${cellSize}px)`;
    board.style.width = (cellSize * COLS) + 'px';
    board.style.height = (cellSize * ROWS) + 'px';
    requestAnimationFrame(() => {
      const r = board.getBoundingClientRect();
      boardRect = { left: r.left, top: r.top };
    });
  }

  function cellAt(row, col) {
    return cells[row * COLS + col];
  }

  function clientToCell(clientX, clientY) {
    const x = clientX - boardRect.left;
    const y = clientY - boardRect.top;
    let col = Math.floor(x / cellSize);
    let row = Math.floor(y / cellSize);
    col = Math.max(0, Math.min(COLS - 1, col));
    row = Math.max(0, Math.min(ROWS - 1, row));
    return { row, col };
  }

  function rectBounds() {
    return {
      r0: Math.min(startRow, curRow),
      r1: Math.max(startRow, curRow),
      c0: Math.min(startCol, curCol),
      c1: Math.max(startCol, curCol),
    };
  }

  function inRect(rect, r, c) {
    return r >= rect.r0 && r <= rect.r1 && c >= rect.c0 && c <= rect.c1;
  }

  // Perf-critical: called on every pointermove during a drag. On Hard mode
  // (228 cells) the old implementation looped over the ENTIRE grid every
  // single call, toggling classList on every cell whether or not its
  // selected-state actually changed. That's the dominant cost of the
  // drag-lag: unnecessary classList writes (each one is a potential style
  // recalc/paint) on cells that were already correct, times up to 228,
  // times however many pointermove events fire per second.
  //
  // Fix: diff the previous rendered rectangle against the new one and only
  // touch cells whose membership actually flipped (entered or left the
  // selection). For a typical drag (growing/shrinking by a row or column at
  // a time) this is O(perimeter delta) instead of O(ROWS*COLS) — a handful
  // of cells instead of all of them. The sum/count readout is computed by
  // iterating only the new rectangle's cells (bounded by selection size, not
  // grid size), which is also far cheaper than a full-grid scan.
  function updateSelectionVisual() {
    const rect = rectBounds();
    selectionBox.style.display = 'block';
    selectionBox.style.left = (rect.c0 * cellSize) + 'px';
    selectionBox.style.top = (rect.r0 * cellSize) + 'px';
    selectionBox.style.width = ((rect.c1 - rect.c0 + 1) * cellSize) + 'px';
    selectionBox.style.height = ((rect.r1 - rect.r0 + 1) * cellSize) + 'px';

    const prev = renderedRect;

    // Un-select cells that were in the previous rect but are not in the new one.
    if (prev) {
      for (let r = prev.r0; r <= prev.r1; r++) {
        for (let c = prev.c0; c <= prev.c1; c++) {
          if (!inRect(rect, r, c)) {
            cellAt(r, c).el.classList.remove('selected', 'over-target');
          }
        }
      }
    }

    // Select cells that are in the new rect but weren't already selected.
    let sum = 0;
    let count = 0;
    let fruit = null;
    let mixedFruit = false;
    for (let r = rect.r0; r <= rect.r1; r++) {
      for (let c = rect.c0; c <= rect.c1; c++) {
        const cell = cellAt(r, c);
        if (cell.removed) continue;
        sum += cell.value;
        count++;
        if (fruit === null) fruit = cell.fruit;
        else if (fruit !== cell.fruit) mixedFruit = true;
        if (!prev || !inRect(prev, r, c)) {
          cell.el.classList.add('selected');
        }
      }
    }

    // Now that the full-rect sum is known, mark every currently-selected cell
    // as over/under the target so the whole selection recolors together.
    // Beginner Mode gates this: with it off, selections always stay yellow.
    // A mixed-fruit selection can never clear regardless of sum (see
    // isMultiFruit()), so it's flagged the same way rather than as "over".
    const isOver = settings.beginner && (mixedFruit || sum > targetSum);
    for (let r = rect.r0; r <= rect.r1; r++) {
      for (let c = rect.c0; c <= rect.c1; c++) {
        const cell = cellAt(r, c);
        if (cell.removed) continue;
        cell.el.classList.toggle('over-target', isOver);
      }
    }
    selectionBox.classList.toggle('mixed-fruit', mixedFruit);

    renderedRect = rect;
    sumEl.textContent = `${count > 0 ? sum : 0}/${targetSum}`;
    return { sum, count };
  }

  function clearSelectionVisual() {
    selectionBox.style.display = 'none';
    selectionBox.classList.remove('mixed-fruit');
    sumEl.textContent = `0/${targetSum}`;
    if (renderedRect) {
      for (let r = renderedRect.r0; r <= renderedRect.r1; r++) {
        for (let c = renderedRect.c0; c <= renderedRect.c1; c++) {
          cellAt(r, c).el.classList.remove('selected', 'over-target');
        }
      }
    }
    renderedRect = null;
  }

  // Trace mode's equivalent of updateSelectionVisual/clearSelectionVisual:
  // same 'selected'/'over-target' classes and sum readout, just driven by an
  // arbitrary traced path instead of a rectangle.
  function updateTraceVisual() {
    const sum = tracePath.reduce((s, cell) => s + cell.value, 0);
    const mixedFruit = tracePath.some(cell => cell.fruit !== tracePath[0].fruit);
    const isOver = settings.beginner && (mixedFruit || sum > targetSum);
    const currentSet = new Set(tracePath);
    tracePrevCells.forEach(cell => {
      if (!currentSet.has(cell)) {
        cell.el.classList.remove('selected', 'over-target');
      }
    });
    tracePath.forEach(cell => {
      cell.el.classList.add('selected');
      cell.el.classList.toggle('over-target', isOver);
    });
    tracePrevCells = tracePath.slice();
    sumEl.textContent = `${tracePath.length > 0 ? sum : 0}/${targetSum}`;
  }

  function clearTraceVisual() {
    tracePath.forEach(cell => cell.el.classList.remove('selected', 'over-target'));
    tracePrevCells = [];
    tracePath = [];
    traceCurrentCell = null;
    sumEl.textContent = `0/${targetSum}`;
  }

  // Two live cells count as connected if every other cell in the rectangular
  // gap between them (in any direction/orientation, however big) is already
  // removed — so a trace can bridge straight lines, diagonals, and large
  // irregular dead zones alike, as long as nothing still-live is being
  // skipped over.
  function cellsConnected(a, b) {
    if (a.row === b.row && a.col === b.col) return false;
    const rowLo = Math.min(a.row, b.row), rowHi = Math.max(a.row, b.row);
    const colLo = Math.min(a.col, b.col), colHi = Math.max(a.col, b.col);
    for (let r = rowLo; r <= rowHi; r++) {
      for (let c = colLo; c <= colHi; c++) {
        if ((r === a.row && c === a.col) || (r === b.row && c === b.col)) continue;
        if (!cellAt(r, c).removed) return false;
      }
    }
    return true;
  }

  // Extend the trace path toward (row, col). There is no backtracking —
  // once a cell has been traced it stays selected for the rest of the drag,
  // even if the finger passes back over it. Passing back through an
  // already-traced cell just moves traceCurrentCell there, so the path can
  // resume extending from that cell toward new ones beyond it (otherwise
  // some valid combos would be unreachable: e.g. tracing through a cell to
  // reach one further along would wrongly un-select everything after it).
  function updateTracePath(row, col) {
    const cell = cellAt(row, col);
    if (cell.removed) return;
    if (tracePath.indexOf(cell) !== -1) {
      traceCurrentCell = cell;
      return;
    }
    if (tracePath.length === 0) {
      tracePath.push(cell);
      traceCurrentCell = cell;
      updateTraceVisual();
      return;
    }
    if (cellsConnected(traceCurrentCell, cell)) {
      tracePath.push(cell);
      traceCurrentCell = cell;
      updateTraceVisual();
    }
  }

  function spawnScorePopup(amount, originRect) {
    const el = document.createElement('div');
    el.className = 'score-popup';
    el.textContent = `+${amount}`;
    el.style.left = (originRect.left + originRect.width / 2) + 'px';
    el.style.top = (originRect.top + originRect.height / 2) + 'px';
    document.body.appendChild(el);
    el.addEventListener('animationend', () => el.remove());
  }

  const MAX_COMBO_BUBBLES = 20; // cap so a huge match doesn't flood the DOM with animated nodes
  // startCount is the running collected-total this apple represents (e.g. a
  // match that brings the total from 3 to 6 labels its bubbles 4, 5, 6) so the
  // count keeps climbing across matches instead of resetting to 1 each time.
  function spawnComboBubbles(cellRects, startCount) {
    cellRects.slice(0, MAX_COMBO_BUBBLES).forEach((rect, i) => {
      const el = document.createElement('div');
      el.className = 'combo-bubble';
      el.textContent = String(startCount + i);
      el.style.left = (rect.left + rect.width / 2) + 'px';
      el.style.top = (rect.top + rect.height / 2) + 'px';
      el.style.animationDelay = `${i * 45}ms`;
      document.body.appendChild(el);
      el.addEventListener('animationend', () => el.remove());
    });
  }

  // Shared by both Box and Trace selection modes: marks matched cells removed
  // and fires all the score/currency/animation side effects of a valid clear.
  function finishMatch(matched, popupOriginRect) {
    const matchedRects = matched.map(cell => cell.el.getBoundingClientRect());
    matched.forEach(cell => {
      cell.removed = true;
      cell.el.classList.add('removed');
    });
    score += matched.length;
    updateScoreDisplay();
    spawnScorePopup(matched.length, popupOriginRect);
    spawnComboBubbles(matchedRects, score - matched.length + 1);
    if (gameMode === 'levels') {
      currency += matched.length;
      saveCurrency();
      updateCurrencyDisplay();
    }
    playPopSound();
  }

  // Shared post-clear check: level-win, or reshuffle if no move remains.
  // Returns true if the round ended/reshuffled (caller should stop early).
  function afterMatchCleared() {
    if (gameMode === 'levels' && score >= levelTarget) {
      endLevelGame('win');
      return true;
    }
    if (running && !hasValidMove()) {
      triggerReshuffle();
      return true;
    }
    return false;
  }

  function endDrag() {
    if (!dragging) return;
    dragging = false;
    if (settings.selectionMode === 'trace') {
      endTraceDrag();
      return;
    }
    const { r0, r1, c0, c1 } = rectBounds();
    let sum = 0;
    let fruit = null;
    let mixedFruit = false;
    const matched = [];
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const cell = cellAt(r, c);
        if (!cell.removed) {
          sum += cell.value;
          matched.push(cell);
          if (fruit === null) fruit = cell.fruit;
          else if (fruit !== cell.fruit) mixedFruit = true;
        }
      }
    }
    if (sum === targetSum && matched.length > 0 && !mixedFruit) {
      const popupOriginRect = selectionBox.getBoundingClientRect();
      finishMatch(matched, popupOriginRect);
      clearSelectionVisual();
      if (afterMatchCleared()) return;
    }
    clearSelectionVisual();
  }

  // Trace mode still only allows clearing a filled rectangle, same shape rule
  // as Box mode — the finger-drawn path just has to happen to cover every
  // still-live cell of one exactly once. Already-removed (cleared earlier)
  // cells inside the bounding box don't count against it, same as Box mode's
  // rectangle drag already ignores removed cells within its bounds — a gap
  // left by previously-cleared apples shouldn't make the rest un-traceable.
  // Since updateTracePath never lets the path contain duplicates (revisiting
  // a cell truncates back to it instead of appending again) and never adds a
  // removed cell in the first place, a path whose length equals the number of
  // live cells in its own row/col bounding box must, by pigeonhole, cover
  // every one of those live cells exactly.
  function pathFormsRectangle(path) {
    if (path.length === 0) return false;
    let minRow = Infinity, maxRow = -Infinity, minCol = Infinity, maxCol = -Infinity;
    path.forEach(cell => {
      minRow = Math.min(minRow, cell.row);
      maxRow = Math.max(maxRow, cell.row);
      minCol = Math.min(minCol, cell.col);
      maxCol = Math.max(maxCol, cell.col);
    });
    let liveCount = 0;
    for (let r = minRow; r <= maxRow; r++) {
      for (let c = minCol; c <= maxCol; c++) {
        if (!cellAt(r, c).removed) liveCount++;
      }
    }
    return path.length === liveCount;
  }

  function endTraceDrag() {
    const sum = tracePath.reduce((s, cell) => s + cell.value, 0);
    const matched = tracePath;
    const mixedFruit = matched.some(cell => cell.fruit !== matched[0].fruit);
    if (sum === targetSum && matched.length > 0 && !mixedFruit && pathFormsRectangle(matched)) {
      const rects = matched.map(cell => cell.el.getBoundingClientRect());
      const left = Math.min(...rects.map(r => r.left));
      const top = Math.min(...rects.map(r => r.top));
      const right = Math.max(...rects.map(r => r.right));
      const bottom = Math.max(...rects.map(r => r.bottom));
      finishMatch(matched, { left, top, width: right - left, height: bottom - top });
      clearTraceVisual();
      if (afterMatchCleared()) return;
    }
    clearTraceVisual();
  }

  // Called when no sum-to-10 rectangle remains among the still-live cells.
  // Instead of ending the round immediately, lock out input, show a "No
  // Moves Left" banner, then reroll every remaining apple's number so play
  // can continue. The lock/banner/animation are staged with timeouts purely
  // so the player has time to notice what's happening before the board
  // changes under them; hasValidMove() is re-checked after the reroll (with
  // a bounded number of retries for the unlucky case) and, only if the board
  // is still stuck afterwards (or fully cleared), do we fall through to the
  // normal end-of-round flow.
  const RESHUFFLE_BANNER_MS = 900;
  const RESHUFFLE_ANIM_MS = 450;

  function computeReshuffledValues() {
    let attempts = 0;
    let ok = false;
    do {
      cells.forEach(cell => {
        if (cell.removed) return;
        cell.value = 1 + Math.floor(Math.random() * MAX_VALUE);
      });
      attempts++;
      ok = hasValidMove();
    } while (!ok && attempts < 20);
    return ok;
  }

  function triggerReshuffle() {
    dragging = false;
    clearSelectionVisual();
    clearInterval(timerId);
    closeHintConfirm();

    // Work out up front whether reshuffling could even produce a valid move
    // (this already covers "zero apples left" and "nothing left could ever
    // sum to the target" — hasValidMove() returns false in both cases). Only
    // show the "No Moves Left! Reshuffling…" banner if it's actually going to
    // reshuffle into a playable board; otherwise showing that banner just to
    // immediately follow it with a game-over screen is redundant, so skip
    // straight to game over instead.
    const ok = computeReshuffledValues();
    if (!ok) {
      if (gameMode === 'levels') {
        endLevelGame('lose');
      } else {
        endGame('nomoves');
      }
      return;
    }

    reshuffling = true;
    reshuffleBanner.classList.remove('hidden');

    setTimeout(() => {
      cells.forEach(cell => {
        if (cell.removed) return;
        const numEl = cell.el.querySelector('.num');
        if (numEl) numEl.textContent = cell.value;
        cell.el.classList.remove('reshuffling');
        void cell.el.offsetWidth; // restart the CSS animation
        cell.el.classList.add('reshuffling');
      });

      setTimeout(() => {
        cells.forEach(cell => cell.el.classList.remove('reshuffling'));
        reshuffleBanner.classList.add('hidden');
        reshuffling = false;
        if (running && !paused) {
          timerId = setInterval(tick, 1000);
        }
      }, RESHUFFLE_ANIM_MS);
    }, RESHUFFLE_BANNER_MS);
  }

  function updateScoreDisplay() {
    scoreEl.textContent = gameMode === 'levels' ? `${score}/${levelTarget}` : String(score);
  }

  // True when the current board mixes more than one fruit kind (see
  // FRUIT_KINDS/activeFruitKinds) — i.e. the "all cells same fruit" rule is
  // actually in effect. Single-fruit boards (every level before Level 11, and
  // all of Classic mode) skip this check entirely and keep the original fast
  // sliding-window logic below.
  function isMultiFruit() {
    return activeFruitKinds.length > 1;
  }

  // Any remaining sum-to-10 rectangle left to clear? Removed cells count as 0.
  // For each pair of rows we accumulate the column sums for that row-band,
  // then slide a two-pointer window over columns (valid since all values are
  // >= 0, so the running sum is monotonic) to find a contiguous span that
  // adds up to exactly 10. This is O(ROWS^2 * COLS), cheap enough to run
  // after every successful clear even on the largest (Hard) board.
  function hasValidMove() {
    if (isMultiFruit()) return !!findHintCellMultiFruit();
    const colAcc = new Array(COLS).fill(0);
    for (let r0 = 0; r0 < ROWS; r0++) {
      colAcc.fill(0);
      for (let r1 = r0; r1 < ROWS; r1++) {
        for (let c = 0; c < COLS; c++) {
          const cell = cellAt(r1, c);
          colAcc[c] += cell.removed ? 0 : cell.value;
        }
        let windowSum = 0;
        let left = 0;
        for (let right = 0; right < COLS; right++) {
          windowSum += colAcc[right];
          while (windowSum > targetSum && left <= right) {
            windowSum -= colAcc[left];
            left++;
          }
          if (windowSum === targetSum && left <= right) return true;
        }
      }
    }
    return false;
  }

  // Same sliding-window search as hasValidMove(), but instead of a plain
  // true/false it returns one live cell belonging to a rectangle that sums
  // to targetSum, for the Hint button to blink.
  function findHintCell() {
    if (isMultiFruit()) return findHintCellMultiFruit();
    const colAcc = new Array(COLS).fill(0);
    for (let r0 = 0; r0 < ROWS; r0++) {
      colAcc.fill(0);
      for (let r1 = r0; r1 < ROWS; r1++) {
        for (let c = 0; c < COLS; c++) {
          const cell = cellAt(r1, c);
          colAcc[c] += cell.removed ? 0 : cell.value;
        }
        let windowSum = 0;
        let left = 0;
        for (let right = 0; right < COLS; right++) {
          windowSum += colAcc[right];
          while (windowSum > targetSum && left <= right) {
            windowSum -= colAcc[left];
            left++;
          }
          if (windowSum === targetSum && left <= right) {
            for (let r = r0; r <= r1; r++) {
              for (let c = left; c <= right; c++) {
                const cell = cellAt(r, c);
                if (!cell.removed) return cell;
              }
            }
          }
        }
      }
    }
    return null;
  }

  // Multi-fruit boards can't use the sliding-window trick above: a live cell
  // of a *different* fruit inside the row/col span makes that whole
  // rectangle invalid even though it doesn't touch the numeric sum, which
  // breaks the "sums are monotonic" assumption the two-pointer window relies
  // on. So instead this brute-forces every distinct (r0,r1,c0,c1) rectangle
  // directly and checks sum + same-fruit-only in one pass. Board sizes in
  // this game are small enough (well under a few hundred cells) that this is
  // still cheap to run after every clear.
  function findHintCellMultiFruit() {
    for (let r0 = 0; r0 < ROWS; r0++) {
      for (let r1 = r0; r1 < ROWS; r1++) {
        for (let c0 = 0; c0 < COLS; c0++) {
          for (let c1 = c0; c1 < COLS; c1++) {
            let sum = 0, count = 0, fruit = null, mixed = false, firstCell = null;
            for (let r = r0; r <= r1 && !mixed; r++) {
              for (let c = c0; c <= c1; c++) {
                const cell = cellAt(r, c);
                if (cell.removed) continue;
                sum += cell.value;
                count++;
                if (!firstCell) firstCell = cell;
                if (fruit === null) fruit = cell.fruit;
                else if (fruit !== cell.fruit) { mixed = true; break; }
              }
            }
            if (!mixed && count > 0 && sum === targetSum) return firstCell;
          }
        }
      }
    }
    return null;
  }

  let pendingHintCell = null;

  function openHintConfirm() {
    if (!running || paused || reshuffling) return;
    const cell = findHintCell();
    if (!cell) return;
    pendingHintCell = cell;
    hintConfirmText.textContent = `Use ${HINT_COST} 🍎 for a hint?`;
    hintConfirmBtn.disabled = currency < HINT_COST;
    const btnRect = hintBtnHud.getBoundingClientRect();
    hintConfirmPopover.classList.remove('hidden');
    hintConfirmPopover.style.left = (btnRect.left + btnRect.width / 2) + 'px';
    hintConfirmPopover.style.top = (btnRect.bottom + 10) + 'px';
  }

  function closeHintConfirm() {
    hintConfirmPopover.classList.add('hidden');
    pendingHintCell = null;
  }

  function confirmHint() {
    if (!pendingHintCell || currency < HINT_COST) { closeHintConfirm(); return; }
    const cell = pendingHintCell;
    closeHintConfirm();
    currency -= HINT_COST;
    saveCurrency();
    updateCurrencyDisplay();
    cell.el.classList.add('hint-blink');
    setTimeout(() => cell.el.classList.remove('hint-blink'), 2000);
  }

  function onPointerDown(e) {
    if (!running || paused || reshuffling) return;
    const { row, col } = clientToCell(e.clientX, e.clientY);
    dragging = true;
    if (settings.selectionMode === 'trace') {
      updateTracePath(row, col);
    } else {
      startRow = curRow = row;
      startCol = curCol = col;
      updateSelectionVisual();
    }
    boardWrap.setPointerCapture && e.pointerId != null && board.setPointerCapture(e.pointerId);
    e.preventDefault();
  }

  // Touch/mouse pointermove can fire far more often than the display can
  // paint (some Android WebViews deliver well over 60 events/sec during a
  // fast drag). Doing a DOM read+write on every single event is wasted work
  // once more than one event lands in the same frame. Instead we just stash
  // the latest coordinates and schedule (at most) one rAF callback to do the
  // actual recompute+DOM write, coalescing any backlog of pointermove events
  // into a single update per animation frame.
  function onPointerMove(e) {
    if (!dragging) return;
    pendingClientX = e.clientX;
    pendingClientY = e.clientY;
    e.preventDefault();
    if (!moveRafScheduled) {
      moveRafScheduled = true;
      requestAnimationFrame(processPendingMove);
    }
  }

  function processPendingMove() {
    moveRafScheduled = false;
    if (!dragging) return;
    const { row, col } = clientToCell(pendingClientX, pendingClientY);
    if (settings.selectionMode === 'trace') {
      updateTracePath(row, col);
      return;
    }
    if (row === curRow && col === curCol) return;
    curRow = row;
    curCol = col;
    updateSelectionVisual();
  }

  function onPointerUp(e) {
    if (!dragging) return;
    endDrag();
    e.preventDefault();
  }

  board.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove, { passive: false });
  window.addEventListener('pointerup', onPointerUp);
  window.addEventListener('pointercancel', onPointerUp);

  // Above 60s, show minutes:seconds (e.g. "1:30") instead of a bare second
  // count like "90" — under 60s just show the plain number as before.
  function formatTime(totalSeconds) {
    if (totalSeconds < 60) return String(totalSeconds);
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function tick() {
    if (zenMode) {
      elapsed++;
      timeEl.textContent = '∞';
      return;
    }
    timeLeft--;
    timeEl.textContent = formatTime(timeLeft);
    if (timeLeft <= 0) {
      if (gameMode === 'levels') {
        endLevelGame('lose');
      } else {
        endGame();
      }
    }
  }

  function startGame() {
    gameMode = 'classic';
    activeFruitKinds = ['apple'];
    applyDifficulty(selectedDifficulty);
    zenMode = selectedTime === 'zen';
    GAME_SECONDS = zenMode ? 0 : computeEffectiveSeconds(selectedDifficulty, selectedTime);
    targetSum = selectedTargetGoal;
    currencyHudItemEl.classList.remove('hidden');
    hintBtnHud.classList.remove('hidden');
    scoreLabelEl.textContent = 'Score';

    score = 0;
    elapsed = 0;
    timeLeft = GAME_SECONDS;
    sumEl.textContent = `0/${targetSum}`;
    updateScoreDisplay();
    timeEl.textContent = zenMode ? '∞' : formatTime(timeLeft);
    setMenuMode(false);
    lobbyOverlay.classList.add('hidden');
    levelSelectOverlay.classList.add('hidden');
    levelResultOverlay.classList.add('hidden');
    startOverlay.classList.add('hidden');
    gameoverOverlay.classList.add('hidden');
    pauseOverlay.classList.add('hidden');
    buildGrid();
    running = true;
    paused = false;
    clearInterval(timerId);
    timerId = setInterval(tick, 1000);
  }

  function startLevel(levelIndex) {
    const level = LEVELS[levelIndex - 1];
    if (!level) return;
    gameMode = 'levels';
    currentLevel = levelIndex;
    activeFruitKinds = FRUIT_KINDS.slice(0, level.fruits || 1);
    levelTarget = level.target;
    targetSum = LEVEL_TARGET_SUM;
    COLS = level.cols;
    ROWS = level.rows;
    MAX_VALUE = level.maxValue;
    zenMode = false;
    GAME_SECONDS = level.seconds;
    currencyHudItemEl.classList.remove('hidden');
    hintBtnHud.classList.remove('hidden');
    scoreLabelEl.textContent = 'Collect 🍎';

    score = 0;
    elapsed = 0;
    timeLeft = GAME_SECONDS;
    sumEl.textContent = `0/${targetSum}`;
    continueCount = 0;
    updateScoreDisplay();
    timeEl.textContent = formatTime(timeLeft);
    setMenuMode(false);
    lobbyOverlay.classList.add('hidden');
    levelSelectOverlay.classList.add('hidden');
    levelResultOverlay.classList.add('hidden');
    gameoverOverlay.classList.add('hidden');
    pauseOverlay.classList.add('hidden');
    buildGrid();
    running = false;
    paused = false;
    clearInterval(timerId);
    levelIntroTargetEl.textContent = String(levelTarget);
    levelIntroOverlay.classList.remove('hidden');
    startLevelIntroCountdown();
  }

  function startLevelIntroCountdown() {
    let count = 3;
    levelIntroCountdownEl.textContent = String(count);
    clearInterval(levelIntroTimerId);
    levelIntroTimerId = setInterval(() => {
      count--;
      if (count > 0) {
        levelIntroCountdownEl.textContent = String(count);
      } else {
        clearInterval(levelIntroTimerId);
        beginLevelPlay();
      }
    }, 1000);
  }

  function beginLevelPlay() {
    clearInterval(levelIntroTimerId);
    levelIntroOverlay.classList.add('hidden');
    running = true;
    paused = false;
    clearInterval(timerId);
    timerId = setInterval(tick, 1000);
  }

  function endGame(reason) {
    running = false;
    paused = false;
    clearInterval(timerId);
    dragging = false;
    clearSelectionVisual();
    pauseOverlay.classList.add('hidden');
    finalScoreEl.textContent = score;
    gameoverTitleEl.textContent = reason === 'nomoves' ? 'No More Moves!'
      : reason === 'quit' ? 'Game Over'
      : "Time's Up!";

    const prevBest = bestScores[bestScoreKey()] || 0;
    const isNewBest = score > prevBest;
    if (isNewBest) {
      bestScores[bestScoreKey()] = score;
      saveBestScores();
    }
    newBestCalloutEl.classList.toggle('hidden', !isNewBest);
    gameoverBestEl.textContent = `Best: ${bestScores[bestScoreKey()] || 0}`;
    refreshBestScoreDisplay();

    gameoverOverlay.classList.remove('hidden');
  }

  function endLevelGame(result) {
    running = false;
    paused = false;
    clearInterval(timerId);
    dragging = false;
    clearSelectionVisual();
    closeHintConfirm();
    pauseOverlay.classList.add('hidden');

    const won = result === 'win';
    if (won) {
      if (levelProgress.completed.indexOf(currentLevel) === -1) {
        levelProgress.completed.push(currentLevel);
      }
      levelProgress.unlocked = Math.max(levelProgress.unlocked, Math.min(currentLevel + 1, LEVELS.length));
      saveLevelProgress();
    }

    levelResultTitleEl.textContent = won ? 'Level Complete!' : "Time's Up!";
    levelResultScoreEl.textContent = `Score: ${score} / ${levelTarget}`;
    levelNextBtn.classList.toggle('hidden', !(won && currentLevel < LEVELS.length));
    levelContinueBtn.classList.toggle('hidden', won);
    if (!won) {
      const cost = currentContinueCost();
      levelContinueBtn.textContent = `Pay ${cost} 🍎 for +${CONTINUE_SECONDS}s`;
      levelContinueBtn.disabled = currency < cost;
    }
    levelResultOverlay.classList.remove('hidden');
  }

  function continueLevelWithCurrency() {
    const cost = currentContinueCost();
    if (currency < cost) return;
    currency -= cost;
    continueCount++;
    saveCurrency();
    updateCurrencyDisplay();
    timeLeft += CONTINUE_SECONDS;
    timeEl.textContent = formatTime(timeLeft);
    levelResultOverlay.classList.add('hidden');
    running = true;
    paused = false;
    clearInterval(timerId);
    timerId = setInterval(tick, 1000);
  }

  function quitLevelToSelect() {
    running = false;
    paused = false;
    clearInterval(timerId);
    dragging = false;
    clearSelectionVisual();
    closeHintConfirm();
    pauseOverlay.classList.add('hidden');
    clearInterval(levelIntroTimerId);
    levelIntroOverlay.classList.add('hidden');
    showLevelSelect();
  }

  // ---- Lobby / level-select navigation --------------------------------------
  // The board/HUD are only meaningful while a round is actually being played;
  // on every pre-game menu screen (lobby, classic config, level select) they
  // must be hidden so the shared organic background (#global-bg) is what
  // shows through instead of the live apple grid sitting underneath.
  function setMenuMode(isMenu) {
    hudEl.classList.toggle('hidden', isMenu);
    boardWrap.classList.toggle('hidden', isMenu);
  }

  function showLobby() {
    setMenuMode(true);
    startOverlay.classList.add('hidden');
    levelSelectOverlay.classList.add('hidden');
    levelResultOverlay.classList.add('hidden');
    lobbyOverlay.classList.remove('hidden');
  }

  function showClassicMenu() {
    setMenuMode(true);
    lobbyOverlay.classList.add('hidden');
    startOverlay.classList.remove('hidden');
  }

  function showLevelSelect() {
    setMenuMode(true);
    lobbyOverlay.classList.add('hidden');
    levelResultOverlay.classList.add('hidden');
    clearInterval(levelIntroTimerId);
    levelIntroOverlay.classList.add('hidden');
    renderLevelSelect();
    levelSelectOverlay.classList.remove('hidden');
  }

  function renderLevelSelect() {
    levelGridEl.innerHTML = '';
    LEVELS.forEach((level, i) => {
      const levelIndex = i + 1;
      const btn = document.createElement('button');
      btn.className = 'level-btn';
      btn.textContent = String(levelIndex);
      const unlocked = levelIndex <= levelProgress.unlocked;
      const completed = levelProgress.completed.indexOf(levelIndex) !== -1;
      btn.classList.toggle('unlocked', unlocked);
      btn.classList.toggle('completed', completed);
      btn.classList.toggle('locked', !unlocked);
      btn.disabled = !unlocked;
      if (unlocked) {
        btn.addEventListener('click', () => {
          tryFullscreenAndOrientation();
          startLevel(levelIndex);
        });
      }
      levelGridEl.appendChild(btn);
    });
  }

  lobbyLevelsBtn.addEventListener('click', showLevelSelect);
  lobbyClassicBtn.addEventListener('click', showClassicMenu);
  classicBackBtn.addEventListener('click', showLobby);
  levelSelectBackBtn.addEventListener('click', showLobby);

  levelNextBtn.addEventListener('click', () => {
    tryFullscreenAndOrientation();
    startLevel(currentLevel + 1);
  });
  levelRetryBtn.addEventListener('click', () => {
    tryFullscreenAndOrientation();
    startLevel(currentLevel);
  });
  levelBackBtn.addEventListener('click', () => {
    levelResultOverlay.classList.add('hidden');
    showLevelSelect();
  });
  levelContinueBtn.addEventListener('click', continueLevelWithCurrency);

  function tryFullscreenAndOrientation() {
    const el = document.documentElement;
    if (el.requestFullscreen) {
      el.requestFullscreen().catch(() => {});
    }
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock('landscape').catch(() => {});
    }
  }

  startBtn.addEventListener('click', () => {
    tryFullscreenAndOrientation();
    startGame();
  });
  restartBtn.addEventListener('click', () => {
    setMenuMode(true);
    startOverlay.classList.remove('hidden');
    gameoverOverlay.classList.add('hidden');
  });

  function openPause() {
    if (!running || paused || reshuffling) return;
    paused = true;
    dragging = false;
    clearSelectionVisual();
    clearInterval(timerId);
    closeHintConfirm();
    pauseOverlay.classList.remove('hidden');
  }

  function closePauseAndResume() {
    paused = false;
    pauseOverlay.classList.add('hidden');
    if (running) timerId = setInterval(tick, 1000);
  }

  pauseBtnHud.addEventListener('click', openPause);
  hintBtnHud.addEventListener('click', openHintConfirm);
  hintConfirmBtn.addEventListener('click', confirmHint);
  // Tapping anywhere outside the popover cancels it — capture phase so this
  // runs before the board's own pointerdown handler, and stopPropagation
  // keeps that same outside tap from also starting a drag-select on the
  // board underneath.
  window.addEventListener('pointerdown', (e) => {
    if (hintConfirmPopover.classList.contains('hidden')) return;
    if (hintConfirmPopover.contains(e.target) || e.target === hintBtnHud) return;
    closeHintConfirm();
    e.stopPropagation();
    e.preventDefault();
  }, true);

  pauseContinueBtn.addEventListener('click', closePauseAndResume);

  pauseRetryBtn.addEventListener('click', () => {
    paused = false;
    pauseOverlay.classList.add('hidden');
    if (gameMode === 'levels') {
      startLevel(currentLevel);
    } else {
      startGame();
    }
  });

  pauseQuitBtn.addEventListener('click', () => {
    pauseOverlay.classList.add('hidden');
    if (gameMode === 'levels') {
      quitLevelToSelect();
    } else {
      endGame('quit');
    }
  });

  pauseSettingsBtn.addEventListener('click', () => {
    settingsOverlay.classList.remove('hidden');
  });

  window.addEventListener('resize', layout);
  window.addEventListener('orientationchange', () => setTimeout(layout, 200));

  // ---- Tutorial overlay -------------------------------------------------
  function openTutorial() {
    tutorialPausedGame = running;
    if (running) clearInterval(timerId);
    tutorialOverlay.classList.remove('hidden');
  }
  function closeTutorial() {
    tutorialOverlay.classList.add('hidden');
    try { localStorage.setItem(LS_TUTORIAL_KEY, 'true'); } catch (e) {}
    if (tutorialPausedGame && running) {
      timerId = setInterval(tick, 1000);
    }
    tutorialPausedGame = false;
  }
  helpBtnMenu.addEventListener('click', openTutorial);
  helpBtnHud.addEventListener('click', openTutorial);
  tutorialCloseBtn.addEventListener('click', closeTutorial);

  let hasSeenTutorial = false;
  try { hasSeenTutorial = localStorage.getItem(LS_TUTORIAL_KEY) === 'true'; } catch (e) {}
  if (!hasSeenTutorial) {
    openTutorial();
  }

  // ---- Settings overlay ---------------------------------------------------
  settingsBtn.addEventListener('click', () => {
    settingsOverlay.classList.remove('hidden');
  });
  settingsCloseBtn.addEventListener('click', () => {
    settingsOverlay.classList.add('hidden');
  });

  soundToggle.addEventListener('click', () => {
    settings.sound = !settings.sound;
    setToggleBtn(soundToggle, settings.sound, 'On', 'Off');
    saveSettings();
  });
  bigToggle.addEventListener('click', () => {
    settings.big = !settings.big;
    setToggleBtn(bigToggle, settings.big, 'On', 'Off');
    applySettingsToDom();
    saveSettings();
  });
  themeToggle.addEventListener('click', () => {
    settings.theme = settings.theme === 'light' ? 'dark' : 'light';
    setToggleBtn(themeToggle, settings.theme === 'light', 'Light', 'Dark');
    applySettingsToDom();
    saveSettings();
  });
  beginnerToggle.addEventListener('click', () => {
    settings.beginner = !settings.beginner;
    setToggleBtn(beginnerToggle, settings.beginner, 'On', 'Off');
    saveSettings();
  });
  buildGrid();
})();

// ---- Remote update check --------------------------------------------------
// Self-hosted OTA updates via @capgo/capacitor-updater: on every launch, fetch
// a small version manifest from GitHub (committed by `npm run release`) and,
// if it names a newer version than the bundle currently running, download and
// activate it. Entirely separate from the game IIFE above so a problem here
// can never break gameplay; silently does nothing if offline, not running
// inside the native app (e.g. a plain desktop browser), or already current.
(function () {
  const MANIFEST_URL = 'https://raw.githubusercontent.com/yejunbaek/applegame/main/updates/version.json';

  function getUpdater() {
    return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater;
  }

  async function checkForUpdate() {
    const updater = getUpdater();
    if (!updater) return;
    try { await updater.notifyAppReady(); } catch (e) {}

    let manifest;
    try {
      const res = await fetch(MANIFEST_URL, { cache: 'no-store' });
      manifest = await res.json();
    } catch (e) {
      return; // offline or manifest unreachable — keep playing on the current bundle
    }
    if (!manifest || !manifest.version || !manifest.url) return;

    let current;
    try {
      current = await updater.current();
    } catch (e) {
      return;
    }
    const currentVersion = current && current.bundle && current.bundle.version;
    if (manifest.version === currentVersion) return; // already up to date

    try {
      const bundle = await updater.download({ url: manifest.url, version: manifest.version });
      await updater.set(bundle); // activates the new bundle and reloads the app
    } catch (e) {
      // Download or activation failed (e.g. connection dropped mid-download) —
      // the plugin keeps the current bundle running, so just leave it alone.
    }
  }

  checkForUpdate();
})();
